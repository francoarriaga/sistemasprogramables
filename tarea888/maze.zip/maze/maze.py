import pygame
from data.config import SCREEN_WIDTH, SCREEN_HEIGHT, WHITE, BLACK, RED
from data.player import Player
from data.game_logic import GameLogic

pygame.init()
pygame.joystick.init()

def main_menu(screen, font, joystick):
    while True:
        screen.fill(BLACK)
        title_text = font.render("Juego de Laberintos", True, WHITE)
        play_text = font.render("Presiona ENTER o Botón A para Jugar", True, WHITE)
        quit_text = font.render("Presiona B para Salir", True, WHITE)

        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, 150))
        screen.blit(play_text, (SCREEN_WIDTH // 2 - play_text.get_width() // 2, 300))
        screen.blit(quit_text, (SCREEN_WIDTH // 2 - quit_text.get_width() // 2, 400))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Presiona ENTER para Jugar
                    return
                if event.key == pygame.K_ESCAPE:  # Presiona ESC para Salir
                    pygame.quit()
                    exit()

        # Detectar botones del joystick
        if joystick:
            if joystick.get_button(0):  # Botón "A" para jugar
                return
            if joystick.get_button(1):  # Botón "B" para salir
                pygame.quit()
                exit()

def show_victory_message(screen):
    """Muestra un mensaje de victoria cuando se completan todos los niveles."""
    font_big = pygame.font.Font(None, 72)  # Fuente grande
    victory_text1 = font_big.render("¡Haz ganado!", True, RED)
    victory_text2 = font_big.render("Mario ha alcanzado a su novia", True, RED)

    screen.fill(WHITE)
    screen.blit(victory_text1, (SCREEN_WIDTH // 2 - victory_text1.get_width() // 2, SCREEN_HEIGHT // 2 - 50))
    screen.blit(victory_text2, (SCREEN_WIDTH // 2 - victory_text2.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

    pygame.display.flip()
    pygame.time.wait(5000)  # Espera 5 segundos antes de salir del juego

def main():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Juego de Laberintos")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 36)

    # Inicializar joystick
    joystick = None
    if pygame.joystick.get_count() > 0:
        joystick = pygame.joystick.Joystick(0)
        joystick.init()

    # Mostrar menú principal
    main_menu(screen, font, joystick)

    player = Player(50, 50)
    game = GameLogic()

    countdown = 10
    start_time = pygame.time.get_ticks()
    running = True
    time_out = False

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Detectar botón "B" para salir durante el juego
        if joystick and joystick.get_button(1):  # Botón "B"
            running = False

        keys = pygame.key.get_pressed()

        # Movimiento con joystick
        dx, dy = 0, 0
        if joystick:
            # Obtener los valores de los ejes del joystick
            axis_x = joystick.get_axis(0)  # Eje horizontal
            axis_y = joystick.get_axis(1)  # Eje vertical

            # Traducir los valores del joystick a movimientos
            if abs(axis_x) > 0.2:  # Umbral de sensibilidad
                dx = int(axis_x * 5)  # Ajusta la velocidad
            if abs(axis_y) > 0.2:
                dy = int(axis_y * 5)

        if not time_out:
            player.move_with_joystick(dx, dy, game.maze.walls)

        if player.check_goal(game.maze.goal):
            if game.is_last_level():  # Verificar si es el último nivel
                show_victory_message(screen)  # Mostrar el mensaje de victoria
                running = False
            else:
                game.next_level()
                player = Player(50, 50)
                start_time = pygame.time.get_ticks()

        elapsed_time = (pygame.time.get_ticks() - start_time) // 1000
        time_left = countdown - elapsed_time

        if time_left <= 0:
            time_out = True
            time_left = 0

        screen.fill(WHITE)

        if not time_out:
            game.maze.draw(screen)
            player.draw(screen)

        if time_out:
            timeout_text = font.render("¡Tiempo Agotado!", True, RED)
            screen.blit(timeout_text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2))
            pygame.display.flip()
            pygame.time.wait(3000)
            running = False
        else:
            timer_text = font.render(f"Tiempo: {time_left}s", True, WHITE)
            screen.blit(timer_text, (20, 10))

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
