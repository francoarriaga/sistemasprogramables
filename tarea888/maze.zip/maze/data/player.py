import pygame
import os
from data.config import PLAYER_SIZE, PLAYER_SPEED

# Ruta base dinámica
ruta_base = os.path.dirname(__file__)
ruta_assets = os.path.join(ruta_base, "..", "assets")

class Player:
    def __init__(self, x, y):
        # Cargar imágenes para animación (listas para cada dirección)
        self.images = {
            "up": [pygame.image.load(os.path.join(ruta_assets, f"mario_up_{i}.png")) for i in range(1, 4)],
            "down": [pygame.image.load(os.path.join(ruta_assets, f"mario_down_{i}.png")) for i in range(1, 4)],
            "left": [pygame.image.load(os.path.join(ruta_assets, f"mario_left_{i}.png")) for i in range(1, 4)],
            "right": [pygame.image.load(os.path.join(ruta_assets, f"mario_right_{i}.png")) for i in range(1, 4)],
        }
        self.current_direction = "down"  # Dirección inicial
        self.current_frame = 0  # Fotograma actual
        self.animation_speed = 0.1  # Velocidad de la animación
        self.animation_counter = 0  # Contador para manejar la velocidad
        self.rect = self.images["down"][0].get_rect(topleft=(x, y))

    def move(self, keys, walls):
        dx, dy = 0, 0
        moving = False

        if keys[pygame.K_UP]:
            dy = -PLAYER_SPEED
            self.current_direction = "up"
            moving = True
        if keys[pygame.K_DOWN]:
            dy = PLAYER_SPEED
            self.current_direction = "down"
            moving = True
        if keys[pygame.K_LEFT]:
            dx = -PLAYER_SPEED
            self.current_direction = "left"
            moving = True
        if keys[pygame.K_RIGHT]:
            dx = PLAYER_SPEED
            self.current_direction = "right"
            moving = True

        # Mover y verificar colisiones
        self.rect.x += dx
        if self.check_collision(walls):
            self.rect.x -= dx

        self.rect.y += dy
        if self.check_collision(walls):
            self.rect.y -= dy

        # Actualizar animación solo si el jugador se mueve
        if moving:
            self.animation_counter += self.animation_speed
            if self.animation_counter >= 1:
                self.animation_counter = 0
                self.current_frame = (self.current_frame + 1) % len(self.images[self.current_direction])

    def check_collision(self, walls):
        return any(self.rect.colliderect(wall) for wall in walls)

    def check_goal(self, goal):
        return self.rect.colliderect(goal)

    def draw(self, screen):
        # Dibujar el fotograma actual
        current_image = self.images[self.current_direction][self.current_frame]
        screen.blit(current_image, self.rect)
     
    def move_with_joystick(self, dx, dy, walls):
        moving = False

        # Determinar la dirección basada en dx y dy
        if dx > 0:  # Movimiento a la derecha
            self.current_direction = "right"
            moving = True
        elif dx < 0:  # Movimiento a la izquierda
            self.current_direction = "left"
            moving = True

        if dy > 0:  # Movimiento hacia abajo
            self.current_direction = "down"
            moving = True
        elif dy < 0:  # Movimiento hacia arriba
            self.current_direction = "up"
            moving = True

        # Mover y verificar colisiones
        self.rect.x += dx
        if self.check_collision(walls):
            self.rect.x -= dx

        self.rect.y += dy
        if self.check_collision(walls):
            self.rect.y -= dy

        # Actualizar animación solo si el jugador se mueve
        if moving:
            self.animation_counter += self.animation_speed
            if self.animation_counter >= 1:
                self.animation_counter = 0
                self.current_frame = (self.current_frame + 1) % len(self.images[self.current_direction])
