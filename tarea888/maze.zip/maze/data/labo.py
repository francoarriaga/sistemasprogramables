import pygame
import os
from data.config import BLACK, GREEN

class Maze:
    def __init__(self, level_data):
        self.walls = []
        self.goal = None

        # Base path dinámico
        ruta_base = os.path.dirname(__file__)
        ruta_assets = os.path.join(ruta_base, "..", "assets")

        # Cargar imágenes con rutas dinámicas
        self.wall_image = pygame.transform.scale(
            pygame.image.load(os.path.join(ruta_assets, "brick1.png")),
            (40, 40)
        )
        self.goal_image = pygame.image.load(os.path.join(ruta_assets, "peach.png"))

        # Cargar el laberinto
        self.load_maze(level_data)

    def load_maze(self, level_data):
        for row_index, row in enumerate(level_data):
            for col_index, cell in enumerate(row):
                if cell == "1":  # Pared
                    wall = pygame.Rect(col_index * 40, row_index * 40, 40, 40)
                    self.walls.append(wall)
                elif cell == "E":  # Meta
                    self.goal = pygame.Rect(col_index * 40, row_index * 40, 40, 40)

    def draw(self, screen):
        for wall in self.walls:
            screen.blit(self.wall_image, wall.topleft)
        if self.goal:
            screen.blit(self.goal_image, self.goal.topleft)
